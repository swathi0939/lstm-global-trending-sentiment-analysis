"""
Streamlit live demo — LSTM Sentiment Analysis (Global Trending Topics 2026)

Run with:
    streamlit run app.py
"""
import os
import pickle

import numpy as np
import streamlit as st
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing.sequence import pad_sequences

from src.preprocess import clean_text

MODEL_DIR = os.path.join(os.path.dirname(__file__), "model")
MODEL_PATH = os.path.join(MODEL_DIR, "lstm_sentiment_model.keras")
TOKENIZER_PATH = os.path.join(MODEL_DIR, "tokenizer.pkl")

st.set_page_config(page_title="LSTM Sentiment Analysis", page_icon="📰")


@st.cache_resource
def load_artifacts():
    model = load_model(MODEL_PATH)
    with open(TOKENIZER_PATH, "rb") as f:
        bundle = pickle.load(f)
    return model, bundle["tokenizer"], bundle["max_length"], bundle["idx2label"]


st.title("LSTM Sentiment Analysis — Global Trending Topics 2026")
st.caption("Trained on rows 140–210 of the Global Trending Topics 2026 dataset (71 records).")

if not (os.path.exists(MODEL_PATH) and os.path.exists(TOKENIZER_PATH)):
    st.error(
        "Model or tokenizer not found. Run `python src/train_lstm.py` first "
        "to train and save the model before launching this app."
    )
    st.stop()

model, tokenizer, max_length, idx2label = load_artifacts()

text_input = st.text_area("Enter headline or social-media text", height=100)

if st.button("Predict Sentiment"):
    if not text_input.strip():
        st.warning("Please enter some text first.")
    else:
        cleaned = clean_text(text_input)
        seq = tokenizer.texts_to_sequences([cleaned])
        padded = pad_sequences(seq, maxlen=max_length, padding="post", truncating="post")
        probs = model.predict(padded, verbose=0)[0]
        pred_idx = int(np.argmax(probs))
        label = idx2label[pred_idx]
        confidence = float(probs[pred_idx]) * 100

        color = {"positive": "green", "negative": "red", "neutral": "orange"}[label]
        st.markdown(f"### Sentiment: :{color}[{label.capitalize()}]")
        st.metric("Confidence", f"{confidence:.2f}%")

        st.write("Class probabilities:")
        for idx, lbl in idx2label.items():
            st.write(f"- {lbl}: {probs[idx]*100:.2f}%")
